plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.invoicearchive"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.invoicearchive"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    // Bundled Latin text-recognition model: designed for on-device OCR.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
