package com.example.invoicearchive

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

data class Invoice(val id: Long, val store: String, val number: String, val date: String, val imagePath: String)

class InvoiceDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "invoices.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store TEXT NOT NULL,
            number TEXT NOT NULL,
            date TEXT NOT NULL,
            image_path TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX idx_invoice_number ON invoices(number)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(store: String, number: String, date: String, imagePath: String): Long {
        val values = ContentValues().apply {
            put("store", store); put("number", number); put("date", date)
            put("image_path", imagePath); put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("invoices", null, values)
    }
    fun all(query: String = ""): List<Invoice> {
        val result = mutableListOf<Invoice>()
        val q = "%${query.trim()}%"
        readableDatabase.rawQuery(
            "SELECT id,store,number,date,image_path FROM invoices WHERE store LIKE ? OR number LIKE ? OR date LIKE ? ORDER BY created_at DESC",
            arrayOf(q, q, q)
        ).use { c ->
            while (c.moveToNext()) result.add(Invoice(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4)))
        }
        return result
    }
    fun delete(id: Long) { writableDatabase.delete("invoices", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: InvoiceDb
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var currentImagePath: String? = null
    private val pickImage = 1001
    private val takePhoto = 1002
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = InvoiceDb(this)
        showHome()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xFFF7F8FA.toInt())
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }
    private fun showHome() {
        val root = baseLayout()
        root.addView(TextView(this).apply {
            text = "أرشيف الفواتير"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(0xFF183153.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        search = EditText(this).apply {
            hint = "ابحث برقم الفاتورة أو المتجر أو التاريخ"
            singleLine = true
            addTextChangedListener(SimpleTextWatcher { refreshList() })
        }
        root.addView(search)
        root.addView(button("＋ تصوير فاتورة جديدة") { chooseCapture() })
        root.addView(button("اختيار صورة من المعرض") { pickFromGallery() })
        root.addView(button("تصدير نسخة احتياطية") { exportBackup() })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshList()
    }
    private fun refreshList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString() else ""
        val invoices = db.all(q)
        if (invoices.isEmpty()) list.addView(TextView(this).apply {
            text = if (q.isBlank()) "لا توجد فواتير محفوظة بعد." else "لا توجد نتائج مطابقة."
            textSize = 16f; setPadding(8, 24, 8, 24)
        })
        invoices.forEach { invoice ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            row.addView(TextView(this).apply {
                text = "المتجر: ${invoice.store}\nرقم الفاتورة: ${invoice.number}\nالتاريخ: ${invoice.date}"
                textSize = 16f
            })
            row.addView(button("عرض الصورة") { showInvoice(invoice) })
            row.addView(button("حذف الفاتورة") {
                AlertDialog.Builder(this).setTitle("تأكيد الحذف")
                    .setMessage("هل تريد حذف سجل الفاتورة؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("حذف") { _, _ ->
                        db.delete(invoice.id)
                        File(invoice.imagePath).delete()
                        refreshList()
                    }.show()
            })
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }
    private fun chooseCapture() {
        val options = arrayOf("التقاط صورة بالكاميرا", "اختيار صورة من المعرض")
        AlertDialog.Builder(this).setTitle("إضافة فاتورة")
            .setItems(options) { _, which -> if (which == 0) takePhotoNow() else pickFromGallery() }.show()
    }
    private fun takePhotoNow() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, takePhoto)
        } else Toast.makeText(this, "الكاميرا غير متاحة", Toast.LENGTH_LONG).show()
    }
    private fun pickFromGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        startActivityForResult(intent, pickImage)
    }
    @Deprecated("Legacy activity result API used for broad compatibility in this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 1003) {
            val target = data.data ?: return
            try {
                contentResolver.openOutputStream(target)?.use { output ->
                    java.util.zip.ZipOutputStream(output).use { zip ->
                        val dbFile = getDatabasePath("invoices.db")
                        if (dbFile.exists()) {
                            zip.putNextEntry(java.util.zip.ZipEntry("invoices.db"))
                            dbFile.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                        db.all().forEach { invoice ->
                            val imageFile = File(invoice.imagePath)
                            if (imageFile.exists()) {
                                zip.putNextEntry(java.util.zip.ZipEntry("images/${imageFile.name}"))
                                imageFile.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                    }
                }
                toast("تم تصدير النسخة الاحتياطية")
            } catch (e: Exception) {
                toast("تعذر تصدير النسخة الاحتياطية: ${e.message}")
            }
            return
        }
        try {
            val bitmap: Bitmap? = when (requestCode) {
                pickImage -> data.data?.let { uri -> contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
                takePhoto -> @Suppress("DEPRECATION") (data.extras?.get("data") as? Bitmap)
                else -> null
            }
            if (bitmap == null) { toast("تعذر قراءة الصورة"); return }
            val file = File(filesDir, "invoice_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            currentImagePath = file.absolutePath
            runOcr(bitmap, file.absolutePath)
        } catch (e: Exception) { toast("تعذر فتح الصورة: ${e.message}") }
    }
    private fun runOcr(bitmap: Bitmap, path: String) {
        toast("جارٍ قراءة الفاتورة...")
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result -> editExtractedFields(result.text, path) }
            .addOnFailureListener { editExtractedFields("", path) }
    }
    private fun editExtractedFields(text: String, path: String) {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val guessStore = lines.firstOrNull().orEmpty()
        val guessNumber = Regex("(?i)(?:invoice|receipt|فاتورة|رقم)\\s*[:#：-]?\\s*([A-Z0-9\\-/]+)")
            .find(text)?.groupValues?.getOrNull(1).orEmpty()
        val guessDate = Regex("\\b(?:\\d{1,4}[-/.]\\d{1,2}[-/.]\\d{1,4})\\b").find(text)?.value.orEmpty()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val store = EditText(this).apply { hint = "اسم المتجر"; setText(guessStore) }
        val number = EditText(this).apply { hint = "رقم الفاتورة"; setText(guessNumber) }
        val date = EditText(this).apply { hint = "تاريخ الفاتورة"; setText(guessDate) }
        panel.addView(TextView(this).apply { text = "راجع البيانات وصححها قبل الحفظ." })
        panel.addView(store); panel.addView(number); panel.addView(date)
        AlertDialog.Builder(this).setTitle("بيانات الفاتورة")
            .setView(panel)
            .setNegativeButton("إلغاء") { _, _ -> File(path).delete() }
            .setPositiveButton("حفظ") { _, _ ->
                val n = number.text.toString().trim()
                if (n.isBlank()) {
                    AlertDialog.Builder(this).setMessage("رقم الفاتورة غير واضح. يمكنك حفظه يدويًا من شاشة المراجعة بعد إدخال الرقم.")
                        .setPositiveButton("حسنًا", null).show()
                } else {
                    db.add(store.text.toString().trim(), n, date.text.toString().trim(), path)
                    toast("تم حفظ الفاتورة")
                    if (::search.isInitialized) search.setText("")
                    refreshList()
                }
            }.show()
    }
    private fun showInvoice(invoice: Invoice) {
        val image = ImageView(this).apply {
            val bmp = BitmapFactory.decodeFile(invoice.imagePath)
            setImageBitmap(bmp); adjustViewBounds = true
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8) }
        content.addView(TextView(this).apply {
            text = "المتجر: ${invoice.store}\nرقم الفاتورة: ${invoice.number}\nالتاريخ: ${invoice.date}"
            textSize = 17f
        })
        content.addView(ScrollView(this).apply { addView(image) }, LinearLayout.LayoutParams(-1, 600))
        AlertDialog.Builder(this).setTitle("تفاصيل الفاتورة").setView(content)
            .setPositiveButton("إغلاق", null).show()
    }
    private fun exportBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "invoice_backup_${System.currentTimeMillis()}.zip")
        }
        startActivityForResult(intent, 1003)
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
class SimpleTextWatcher(private val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
